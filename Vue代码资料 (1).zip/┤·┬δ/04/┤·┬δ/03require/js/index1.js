//console.log('index1.js')

define(function(){
    function fun1(){
      console.log('index1.js')
    }

    fun1();
})