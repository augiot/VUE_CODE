//console.log('index2.js')

define(function(){
	function test(){
		console.log('index2.js')
	}
	test()
})