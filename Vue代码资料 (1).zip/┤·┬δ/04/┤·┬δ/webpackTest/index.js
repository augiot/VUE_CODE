console.log('hello laochen')
console.log('abc12344jgsdaogjaoi')
require('./hello.js')
require('./style.css')