<template>
    <div class="cellpage">
        支付
        <van-cell-group >
            <van-cell title="单元格" value="内容" />
        <van-cell :border='false' title="支付" icon="refund-o" is-link to="/about"/>

        <van-cell title="支付" icon="refund-o" is-link to="/about">
            <van-icon name="phone-o" slot="right-icon" info="9" color="#1989fa" size="20" tag='span' />
        </van-cell>

        <van-cell title="支付" icon="refund-o" is-link to="/about">
            <template slot="right-icon">
                <van-icon name="phone-o" dot  />
            </template>
        </van-cell>
        </van-cell-group>

        <van-cell-group>
        <van-cell title="单元格"  />
        </van-cell-group>
    </div>
</template>

<style lang="less">
    .cellpage{
        width: 100vw;
        height: 100vh;
        background: #efefef;
    }
    .van-cell__title{
        text-align: left;
    }
</style>