export default {
    addNum(state){
      state.num+=2
    },
    setNum(state,value){
      state.num = value
    },
    setDuanzi:function(state,value){
      state.duanzi = value
    }
  }