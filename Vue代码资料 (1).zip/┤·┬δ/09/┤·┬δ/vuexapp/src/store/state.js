export default {
    num:0,
    msg:'hellolaochen',
    age:33,
    duanzi:null
  }