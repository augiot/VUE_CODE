// invoked in worker
//# sourceMappingURL=worker.js.map