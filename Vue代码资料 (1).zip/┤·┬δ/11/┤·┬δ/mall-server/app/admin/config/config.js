// default config
module.exports = {};
//# sourceMappingURL=config.js.map