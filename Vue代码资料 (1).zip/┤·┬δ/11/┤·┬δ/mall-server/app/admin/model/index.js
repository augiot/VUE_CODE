module.exports = class extends think.Model {};
//# sourceMappingURL=index.js.map