module.exports = class extends think.Logic {
  indexAction() {}
};
//# sourceMappingURL=order.js.map