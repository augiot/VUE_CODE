module.exports = class extends think.Logic {
  indexAction() {}
};
//# sourceMappingURL=index.js.map