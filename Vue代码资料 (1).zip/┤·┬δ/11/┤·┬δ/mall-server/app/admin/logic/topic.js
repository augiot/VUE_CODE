module.exports = class extends think.Logic {
  indexAction() {}
};
//# sourceMappingURL=topic.js.map