module.exports = class extends think.Logic {
  indexAction() {}
};
//# sourceMappingURL=upload.js.map