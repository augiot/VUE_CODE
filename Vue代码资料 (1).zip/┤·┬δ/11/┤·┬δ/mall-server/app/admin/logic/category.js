module.exports = class extends think.Logic {
  indexAction() {}
};
//# sourceMappingURL=category.js.map