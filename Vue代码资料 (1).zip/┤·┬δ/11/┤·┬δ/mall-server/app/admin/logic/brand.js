module.exports = class extends think.Logic {
  indexAction() {
    this.allowMethods = 'get';
  }
};
//# sourceMappingURL=brand.js.map