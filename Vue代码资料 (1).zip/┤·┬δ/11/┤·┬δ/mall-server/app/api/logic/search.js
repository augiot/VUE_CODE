module.exports = class extends think.Logic {
  indexAction() {}
};
//# sourceMappingURL=search.js.map