module.exports = class extends think.Logic {
  indexAction() {}
};
//# sourceMappingURL=collect.js.map