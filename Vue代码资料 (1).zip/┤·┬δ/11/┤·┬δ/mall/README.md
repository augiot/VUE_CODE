# 商城

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### API接口文件

assets/config/api.js



### 技术：

1-vant ui框架

2-less-css预编译语言

3-vue

4-vue router

5-vuex

6-axios

7-javascript

8-html5

9-css3

10-vue-cli

11-webpack

