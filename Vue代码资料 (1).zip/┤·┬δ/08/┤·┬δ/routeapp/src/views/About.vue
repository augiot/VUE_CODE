<template>
  <div class="about">
    <h1>This is an about page</h1>
    <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link> |
      <router-link to="/me">个人中心</router-link> |
      <router-link to="/news">新闻</router-link> |
    </div>
  </div>
</template>
