<template>
    <div>
        <h1>404!你所访问的页面不存在</h1>
    </div>
</template>