<template>
    <div>
        <h1>bignews{{content}}</h1>
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    props:['content'],
    mounted(){
        console.log(this)
    }
}
</script>