<template>
    <div>
        <div id="nav">
            <router-link to="/">Home</router-link> |
            <router-link to="/about">About</router-link> |
            <router-link to="/me">个人中心</router-link> |
            <router-link to="/news">新闻</router-link> |
        </div>
        <h1>这是个人中心</h1>
        <button @click="goAbout">按钮</button>
    </div>
</template>


<script>
export default {
    methods:{
        goAbout(event){
            this.$router.push({
                path:'about'
            })
            console.log(this)
        }
    }
}
</script>