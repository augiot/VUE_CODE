<template>
    <div>
        <h1>新闻内容页面:{{id}}{{username}}</h1>
    </div>
</template>


<script>
export default {
    props:['id','username'],
    mounted(){
        console.log(this)
    }
}
</script>