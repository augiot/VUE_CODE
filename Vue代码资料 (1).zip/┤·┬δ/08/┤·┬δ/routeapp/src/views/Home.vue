<template>
  <div class="home">
    <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link> |
      <router-link to="/me">个人中心</router-link> |
      <router-link to="/news">新闻</router-link> |
    </div>
    <img alt="Vue logo" src="../assets/logo.png">
    <button @click="goEvent">跳转至新闻页</button>
    <button @click="go">前进</button>
    <button @click="back">后退</button>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'home',
  components: {
    HelloWorld
  }
  ,methods: {
    goEvent:function(){
      //通过路劲跳转
      this.$router.push({
        //path:"/news/123?username=laochen&password=123456",
        path:'/news/123',
        query:{
          username:"xiaoming",
          password:"8888"
        }
      })
      // this.$router.push({
      //   name:"news",
      //   params:{
      //     id:456
      //   }
      // })

      //替换
      // this.$router.replace({
      //   //path:"/news/123?username=laochen&password=123456",
      //   path:'/news/123',
      //   query:{
      //     username:"xiaoming",
      //     password:"8888"
      //   }
      // },function(){
      //   console.log('成功替换页面')
      // })
    },
    go(){
      this.$router.go(1)
    }
    ,back(){
      this.$router.go(-1)
    }
  },
}
</script>
