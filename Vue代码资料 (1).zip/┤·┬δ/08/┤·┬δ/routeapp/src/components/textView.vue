<template>
    <div>
        <h1>文字子路由</h1>
    </div>
</template>