<template>
    <div>
        <h1>视频子路由</h1>
    </div>
</template>