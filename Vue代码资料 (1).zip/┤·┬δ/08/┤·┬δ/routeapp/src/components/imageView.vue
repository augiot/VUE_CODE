<template>
    <div>
        <h1>图片子路由</h1>
    </div>
</template>