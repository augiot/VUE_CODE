<template>
    <div>
        <h1>这是侧边栏组件</h1>
    </div>
</template>