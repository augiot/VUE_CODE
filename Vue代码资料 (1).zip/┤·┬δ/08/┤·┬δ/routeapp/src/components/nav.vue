<template>
    <div>
        <h1>这是导航组件</h1>
    </div>
</template>