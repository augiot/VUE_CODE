import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import meCom from '../views/Me.vue'
import newsView from '../views/newsView.vue'
import weather from '@/views/weather'
import bignews from '@/views/bignews'
import videoView from '@/components/videoView';
import textView from '@/components/textView';
import imageView from '@/components/imageView';
import navView from '@/components/nav'
import asideView from '@/components/aside'
import page404 from '@/views/page404'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    //component: Home
    components:{
      nav:navView,
      aside:asideView,
      default:Home
    }
  },
  {
    path:"/a",
    //redirect:"/about"
    redirect:(to)=>{
      console.log(to)
      if(to.query.go=='about'){
        return {name:"about"}
      }else{
        return {name:"news",params:{id:456789}}
      }
      
    }
  },
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  {
    path:"/me",
    name:"me",
    alias:"/self",
    component:meCom
  },
  {
    path:"/news/:id",
    name:"news",
    //props:true,
    props:function(route){
      console.log(route)
      return {
        id:route.params.id,
        username:route.query.username}
    },
    component:newsView
  },
  {
    path:'/weather/:city/:area',
    component:weather
  },{
    path:'/bignews/:content',
    props: true,
    component:bignews,
    children:[{
      path:'video',
      component:videoView,
    },{
      path:'text',
      component:textView
    },{
      path:'image',
      component:imageView
    },
    
  ]
  },
  {
    path:"*",
    component:page404
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
