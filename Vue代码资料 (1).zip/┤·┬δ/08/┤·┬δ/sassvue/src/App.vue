<template>
  <div id="app">
   <alert-com v-if="isAlert" :title="title" :content="content" :cancelEvent="cancelEvent" :comfirmEvent="comfirmEvent"></alert-com>
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'
import alertCom from './components/AlertCom'

export default {
  name: 'app',
  data() {
    return {
      title:"跳转页面",
      content:"是否要跳转至百度",
      isAlert:true
    }
  },
  methods: {
    cancelEvent:function(){
      this.isAlert = false;
    },
    comfirmEvent:function(){
      location.href = 'http://www.baidu.com'
    }
  },
  components: {
    HelloWorld,
    alertCom
  }
}
</script>

<style lang="scss">
* {
  margin: 0;
  padding: 0;
}
</style>
