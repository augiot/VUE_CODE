import io from 'socket.io-client'

let  socket = io.connect();

export default socket;